#!/usr/bin/env bash
#
# Copyright (c) 2019 Intel Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

shopt -s extglob
set +H

mkdir -p /mnt/output/home/${EXP_NAME}

mv -t /mnt/output/experiment !(input|output)

mkdir -p /root/.jupyter/custom

echo "document.title = \"${EXP_NAME}\";
Object.defineProperty(document, 'title', {
  set: function(val) {
    document.querySelector('title').childNodes[0].nodeValue = \"${EXP_NAME}\";
  }
});" >> /root/.jupyter/custom/custom.js

jupyter notebook --allow-root
